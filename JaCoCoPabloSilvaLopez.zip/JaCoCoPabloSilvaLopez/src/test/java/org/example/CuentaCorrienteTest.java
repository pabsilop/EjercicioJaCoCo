package org.example;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class CuentaCorrienteTest {

    static CuentaCorriente cuentaCorriente;
    static CuentaCorriente cuentaCorriente2;

    @BeforeAll
    public static void init(){
        cuentaCorriente=new CuentaCorriente("Pablo", 9999, 5000);
        cuentaCorriente2=new CuentaCorriente("Javi", 9999, 5000);
        System.out.println("Creacion de cuentas corrientes");
    }

    @Test
    @DisplayName("DepositarPositivo")
    void depositTrue(){
        assertEquals(true, cuentaCorriente.deposit(50), "Devuelve true al depositar");
    }
    @Test
    @DisplayName("DepositarNegativo")
    void depositFalse(){
        assertEquals(false, cuentaCorriente.deposit(-50), "Devuelve falso al depositar");
    }
    @Test
    @DisplayName("RetirarPositivo")
    void retirarTrue(){
        assertEquals(true, cuentaCorriente.withdraw(15,1), "Devuelve true si la cantidad a depositar es aceptada");
    }
    @Test
    @DisplayName("RetirarNegativo1")
    void retirarFalse1(){
        assertEquals(false, cuentaCorriente.withdraw(-15,1), "Devuelve false si la cantidad es negativa");
    }
    @Test
    @DisplayName("RetirarNegativo2")
    void retirarFalse2(){
        assertEquals(false, cuentaCorriente.withdraw(15,-1), "Devuelve false la comision es negativa");
    }
    @Test
    @DisplayName("RetirarNegativo3")
    void retirarFalse3(){
        assertEquals(false, cuentaCorriente.withdraw(6000,1), "Devuelve false si la cantidad a retirar es mayor que la cantidad de la cuenta" );
    }
    @Test
    @DisplayName("AgregarInteres")
    void agregarInteres(){
        cuentaCorriente.addInterest();
        assertNotEquals(cuentaCorriente.getSaldo(),  cuentaCorriente2.getSaldo());
    }
    @Test
    @DisplayName("DevolverCuenta")
    void devolverCuenta(){
        assertEquals(9999, cuentaCorriente.getAccountNumber(), "Devuelve el número de la cuenta");

    }
    @Test
    @DisplayName("DevolverToString")
    void devolverToString(){
        assertEquals("9999\tJavi\t5.000,00 €", cuentaCorriente2.toString(), "Devuelve el toString");

    }

}
